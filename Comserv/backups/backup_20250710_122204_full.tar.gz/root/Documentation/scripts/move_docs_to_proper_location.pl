#!/usr/bin/env perl
use strict;
use warnings;
use File::Copy;
use File::Path qw(make_path);
use File::Basename;

# Base directories
my $app_root = "/home/shanta/PycharmProjects/comserv2/Comserv";
my $doc_root = "$app_root/root/Documentation";

# Create destination directories if they don't exist
my @doc_dirs = (
    "$doc_root/general",
    "$doc_root/system",
    "$doc_root/deployment",
    "$doc_root/themes",
    "$doc_root/migration"
);

foreach my $dir (@doc_dirs) {
    make_path($dir) unless -d $dir;
}

# Mapping of file patterns to destination directories
my %file_mappings = (
    # Changelog files
    '^\d{4}-\d{2}-.+\.md$' => "$doc_root/changelog",
    
    # Controller documentation
    '^.+Controller\.md$' => "$doc_root/controllers",
    '^[A-Z][a-z]+\.md$' => "$doc_root/controllers",
    
    # Model documentation
    '^ThemeConfig\.md$' => "$doc_root/models",
    
    # Theme system documentation
    '^THEME_SYSTEM.+\.md$' => "$doc_root/themes",
    '^NEW_THEME_SYSTEM.+\.md$' => "$doc_root/themes",
    '^theme_.+\.md$' => "$doc_root/themes",
    
    # System documentation
    '^SYSTEM_.+\.md$' => "$doc_root/system",
    '^DB_CONFIG.+\.md$' => "$doc_root/system",
    '^EMAIL_MODULE.+\.md$' => "$doc_root/system",
    '^ROUTING.+\.md$' => "$doc_root/system",
    
    # Deployment documentation
    '^SERVER_DEPLOYMENT\.md$' => "$doc_root/deployment",
    
    # General documentation (README files)
    '^README\.md$' => "$doc_root/general",
    
    # Default for other files
    '.*' => "$doc_root/general"
);

# Process all markdown files in the application root
my @md_files = glob("$app_root/*.md");
my $moved_count = 0;
my $skipped_count = 0;

print "Moving documentation files to proper locations...\n";

foreach my $file (@md_files) {
    my $basename = basename($file);
    my $destination_dir = "$doc_root/general"; # Default destination
    
    # Find the appropriate destination directory based on filename pattern
    foreach my $pattern (keys %file_mappings) {
        if ($basename =~ /$pattern/) {
            $destination_dir = $file_mappings{$pattern};
            last;
        }
    }
    
    # Create a new filename without "Formatting title from: " prefix
    my $new_basename = $basename;
    $new_basename =~ s/^Formatting title from: //;
    
    my $destination = "$destination_dir/$new_basename";
    
    # Skip if the file already exists in the destination
    if (-e $destination) {
        print "Skipping $basename (already exists at destination)\n";
        $skipped_count++;
        next;
    }
    
    # Move the file
    if (copy($file, $destination)) {
        print "Moved $basename to $destination_dir/\n";
        unlink($file); # Remove the original file
        $moved_count++;
    } else {
        print "Failed to move $basename: $!\n";
        $skipped_count++;
    }
}

print "\nSummary:\n";
print "  $moved_count files moved\n";
print "  $skipped_count files skipped\n";
print "Done.\n";
