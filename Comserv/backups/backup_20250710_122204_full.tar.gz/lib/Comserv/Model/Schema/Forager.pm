package Comserv::Model::Schema::Forager;

use strict;
use base 'DBIx::Class::Schema';

# Load the result classes
__PACKAGE__->load_namespaces();

1;